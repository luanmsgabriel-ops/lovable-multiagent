# Contributing

## Adding a new skill

1. Create a `SKILL.md` in the appropriate category under `skills/`
2. Use this frontmatter (English only):

```markdown
---
name: your-skill-name
description: When this activates. English only.
---
```

3. Must include: protocol, checklist, anti-patterns
4. Create zip with just `SKILL.md` inside (no folder)
5. Add to `zips/` and update README table
6. Open a PR with proof it was tested in a real Lovable project

## Quality bar

- Frontmatter description in English
- Specific — must not apply to any project generically
- Tested in real Lovable project before PR
- Anti-patterns based on real bugs, not hypothetical
