# Lovable Multi-Agent System

> The first documented method to transform Lovable into a distributed multi-agent platform with autonomous evolution. Discovered May 24, 2026.

## What is this

A collection of specialized skills that transforms any Lovable project into a multi-agent system with:

- **Orchestration** — a central agent that delegates to specialists
- **Persistent memory** — full context between sessions
- **Quality loop** — autonomous critic and improver on every output
- **Auto-evolution** — agents that rewrite other agents based on performance
- **Autonomous build** — send a briefing, get a complete product

## Quick start

Install in this order via Settings → Skills → Import → Archive:

### Minimum kit (start here)
1. `zips/orchestrator.zip`
2. `zips/memory-manager.zip`
3. `zips/critic.zip`
4. `zips/improver.zip`
5. `zips/frontend-developer.zip`

Then send any complex request to Lovable. The orchestrator will analyze, delegate to specialists, pass through critic, and correct automatically.

### Full autonomous build kit
Install all zips in `zips/` folder. Then use the briefing template:

```
I want to build a complete startup autonomously.

Activate the loop-controller with the following briefing and don't stop until the product is deployed and working. Fix bugs automatically. Evolve the product when you identify high-impact low-effort opportunities. Show me status after each completed epic.

BRIEFING:
PRODUCT: [name]
DESCRIPTION: [1-2 lines]
PROBLEM: [specific pain]
USER: [specific who — not "everyone"]
CORE FEATURES:
1. [feature]
2. [feature]
3. [feature]
MONETIZATION:
- Free: [what's included]
- Pro (price/mo): [what's included]
DIFFERENTIALS:
- [differentiator]

Start with strategic-advisor validating the briefing. Only proceed to build after validation.
```

## Skills directory

### Core — the brain
| Skill | What it does |
|---|---|
| `orchestrator` | Receives complex requests, analyzes, delegates to specialists in order. Never codes directly. |
| `memory-manager` | Documents architecture, bugs, decisions in `project-memory.md`. Every session starts with full context. |
| `loop-controller` | The maestro. Keeps the build loop running until the product is deployed. |
| `strategic-advisor` | Validates the briefing before building. Identifies gaps, unnecessary features, missed opportunities. |
| `skill-resolver` | Finds or creates missing skills by searching local repo, cloning public repos, or building from scratch. |
| `project-manager` | Breaks the project into epics, stories and tasks. Tracks what's done and what's next. |

### Quality — the immune system
| Skill | What it does |
|---|---|
| `critic` | Evaluates any output 0-10 on technical correctness, a11y, performance, design system. |
| `improver` | Receives critic report and rewrites fixing all blockers and warnings. |
| `bug-detector` | Scans code after each feature identifying bugs, edge cases, broken integrations. |
| `opportunity-scanner` | Identifies evolution opportunities not in the briefing. Executes high-impact low-effort ones autonomously. |

### Build — the arms
| Skill | What it does |
|---|---|
| `architect` | Designs complete architecture before any code. Stack, folder structure, module contracts, data flow. |
| `database-architect` | Full schema, RLS, migrations, indexes. Database decisions are irreversible — this skill gets them right. |
| `frontend-developer` | React/TS with Discovery → Execution → Handoff workflow. TypeScript strict, a11y, semantic tokens. |
| `backend-developer` | Edge functions, Postgres with RLS, external integrations. Never exposes service role key. |
| `api-designer` | API contracts, Zod schemas, envelope format, status codes, pagination. Single source of truth. |
| `project-manager` | Epics, stories, tasks in correct execution order. Tracks progress. |

### Product — the specialists
| Skill | What it does |
|---|---|
| `auth-engineer` | Complete auth flow — register, login, recovery, session, roles, route guards. |
| `billing-engineer` | Full Stripe — plans, checkout, webhooks, customer portal, plan gating. |
| `onboarding-engineer` | First use experience — onboarding flow, empty states, discovery tooltips. |
| `landing-page-engineer` | Complete LP — hero, problem, solution, features, pricing, FAQ, CTA. |
| `deployment-engineer` | Product on air — env vars, health check, monitoring. Declares product ready. |
| `product-copywriter` | Headlines, CTAs, empty states, error messages, microcopy. What makes a product feel professional. |

### Creative — the director
| Skill | What it does |
|---|---|
| `cinematic-lp` | Cinematographic landing pages with creative direction, WebGL/GSAP, narrative scroll. Never uses templates. |

## What this unlocks

Projects that were impossible in Lovable before:

**SaaS with autonomous QA** — every component passes through critic→improver before existing.

**Software agency without human devs** — orchestrator receives briefs, distributes to specialized projects, consolidates and delivers.

**Product that learns from real users** — feedback becomes metrics, metrics feed evolution-engine, agents are rewritten based on what users actually complain about.

**Solo startup with enterprise infrastructure** — security-auditor, qa-expert, documentation-engineer, performance-engineer all running automatically.

## The 10 levels discovered

| Level | Capability |
|---|---|
| 1 | Autonomous skill self-installation with justified decisions |
| 2 | Agent that writes agents with real project bug memory |
| 3 | Autonomous critic→improver loop |
| 4 | Persistent memory between sessions |
| 5 | Self-evolution of weak skills |
| 6 | Real-time cross-project communication |
| 7 | Cross-project quality loop |
| 8 | Cross-project auto-expansion |
| 9 | Distributed meta-orchestrator |
| 10 | Darwinian evolution between projects |

## What the community can add

- Segment-specific skill packs (FinTech, HealthTech, EdTech, AgriTech)
- Skills for specific integrations (WhatsApp, Open Finance, Pix)
- Skills for specific frameworks (Next.js, Remix, Astro)
- Meta-skills that evaluate and improve other skills

## Credits

Discovered and documented by **Luan Gabriel** — May 24, 2026.

All tests performed live, without simulation, with real system responses.

## License

MIT — use, modify, distribute. Just mention the origin if you publish.
